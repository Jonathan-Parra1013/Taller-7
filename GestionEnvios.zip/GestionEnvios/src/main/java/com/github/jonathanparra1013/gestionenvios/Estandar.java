/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.github.jonathanparra1013.gestionenvios;
import java.util.ArrayList;
/**
 *
 * @author jonap
 */
public class Estandar extends Envio {
    private static final double tarifa = 5_000;
    private String direccionEnvio;
    ArrayList<Envio> envios;

    public Estandar(String direccionEnvio, int codigoEnvio, String nombreDestinatario, double peso) {
        super(codigoEnvio, nombreDestinatario, peso);
        
        this.direccionEnvio = direccionEnvio;
        super.valorPagar = 0;
        
        this.envios = new ArrayList<>();
    }

    
    @Override
    public Double calcularCosto() {
       super.valorPagar = tarifa * super.peso;
       return super.valorPagar;
    }
    
    
    
}
