/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.github.jonathanparra1013.gestionenvios;

/**
 *
 * @author jonap
 */

public abstract class Envio {
    protected int codigoEnvio;
    protected String nombreDestinatario;
    protected double peso; 
    protected double valorPagar;

    public Envio(int codigoEnvio, String nombreDestinatario, double peso) {
        this.codigoEnvio = codigoEnvio;
        this.nombreDestinatario = nombreDestinatario;
        this.peso = peso;
        this.valorPagar = 0;
    }
    
    public abstract Double calcularCosto();
}
